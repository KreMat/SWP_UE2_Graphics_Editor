package at.technikum.wien.winterhalder.kreuzriegler.swp.editor.interfaces;

public interface HasThickness {

	public void setThickness(double thickness);

	public double getThickness();

}
