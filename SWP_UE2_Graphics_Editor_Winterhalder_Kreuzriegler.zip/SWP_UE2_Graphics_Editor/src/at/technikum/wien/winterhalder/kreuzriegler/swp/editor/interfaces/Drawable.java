/**
 * 
 */
package at.technikum.wien.winterhalder.kreuzriegler.swp.editor.interfaces;

/**
 * @author richie
 *
 */
public interface Drawable {
	
	public void draw(IRenderer r);

}
