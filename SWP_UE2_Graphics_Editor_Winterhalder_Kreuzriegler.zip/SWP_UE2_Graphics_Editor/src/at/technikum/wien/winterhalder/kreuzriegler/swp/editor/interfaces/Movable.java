/**
 * 
 */
package at.technikum.wien.winterhalder.kreuzriegler.swp.editor.interfaces;

/**
 * @author richie
 *
 */
public interface Movable {

	public void move(double offsetX, double offsetY);
}
