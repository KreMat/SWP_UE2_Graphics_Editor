/**
 * 
 */
package at.technikum.wien.winterhalder.kreuzriegler.swp.editor.interfaces;

/**
 * @author richie
 *
 */
public interface Resizable {

	public void resize(double fromX, double fromY, double toX, double toY);
}
